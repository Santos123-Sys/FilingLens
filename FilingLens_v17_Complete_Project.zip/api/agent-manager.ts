import type { z } from "zod";
import {
  companySchema,
  financialsSchema,
  historySchema,
  marketSchema,
  metadataSchema,
  risksSchema,
  summarySchema,
  type AgentName,
  type FilingClassification,
  type FinancialsResult,
  type MetadataResult,
  type Market,
} from "../contracts/analysis";
import { buildAgentInput, buildMetadataInput, runAgent, runMetadataAgent } from "./analyze";
import { assessCompleteness, assessMetadataCompleteness } from "./completeness";
import { applyFinancialValidation } from "./financial-validation";
import { validateHistorianOutput } from "./historian-validation";
import { validateMarketOutput } from "./market-validation";
import { AiTransient } from "./lib/ai-client";
import { extractDatedFilingEvents } from "./timeline-skill-extraction";
import { researchMarketPeers } from "./market-web-research";

const AGENT_SCHEMAS = {
  profiler: companySchema,
  market: marketSchema,
  risks: risksSchema,
  financials: financialsSchema,
  historian: historySchema,
  synthesizer: summarySchema,
} as const;

export const MANAGED_AGENT_ORDER: AgentName[] = [
  "profiler",
  "market",
  "risks",
  "financials",
  "historian",
  "synthesizer",
];

type ManagedRun = {
  result: unknown;
  diagnostic: ReturnType<typeof assessCompleteness>;
  manager: {
    stage: number;
    totalStages: number;
    agent: AgentName;
    excerptChars: number;
    attempts: number;
    subtools: string[];
  };
  evaluation: {
    schemaValid: true;
    completeness: ReturnType<typeof assessCompleteness>["status"];
  };
};

export function synthesisInput(excerpt: string, priorResults?: Record<string, unknown>): string {
  if (!priorResults) return excerpt;
  const allowed = Object.fromEntries(
    ["profiler", "market", "risks", "financials", "historian"]
      .filter(key => Object.hasOwn(priorResults, key))
      .map(key => [key, priorResults[key]]),
  );
  return `${excerpt}\n\n[Earlier specialist outputs; summarize filing-supported facts only and identify gaps]\n${JSON.stringify(allowed).slice(0, 24_000)}`;
}

async function withManagedRetry<T>(operation: () => Promise<T>): Promise<{ value: T; attempts: number }> {
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      return { value: await operation(), attempts: attempt };
    } catch (error) {
      if (!(error instanceof AiTransient) || attempt === 3) throw error;
    }
  }
  throw new Error("unreachable_retry_state");
}

/**
 * The sole authority for specialist order, schema selection, source slicing
 * and completeness checks. The browser asks it to run one bounded stage at a
 * time, keeping each model call below platform request-duration limits.
 */
export const agentManager = {
  plan() {
    return {
      manager: "FilingLens Agent Manager",
      schemaVersion: "2.0",
      metadataStage: "metadata",
      agents: MANAGED_AGENT_ORDER,
      dashboardStage: "prebuilt-dashboard-mapping",
      retryBoundary: "per-stage",
      integrations: [
        { skill: "equity-research", stage: "profiler", integration: "prompt_method_only", mode: "tear-sheet identity checks; external cross-check skipped", externalResearch: "unavailable" },
        { skill: "market-research-brief", stage: "market", integration: "prompt_method_typescript_and_cited_web_search", mode: "filing-first peer checks, then cited competitor research only when the filing names none; filing-only segment/geography trends", externalResearch: "conditional_openai_web_search" },
        { skill: "financial-ratio-toolkit", stage: "financials", integration: "typescript_calculation", mode: "mapped filing-only ratios; market-data metrics omitted" },
        { skill: "financial-statement-analyzer", stage: "financials", integration: "typescript_calculation", mode: "comparable-period trends and ten anomaly screens" },
        { skill: "filing-timeline-extractor", stage: "historian", integration: "typescript_extraction_and_validation", mode: "filing-only dated-excerpt fallback and timeline validation; Python CLI not invoked", externalResearch: "unavailable" },
      ],
    };
  },

  async runMetadata(
    market: Market,
    filingText: string,
    classification: FilingClassification,
  ) {
    const excerpt = buildMetadataInput(filingText);
    const { value, attempts } = await withManagedRetry(
      () => runMetadataAgent(market, excerpt, metadataSchema),
    );
    const result = value as MetadataResult;
    result.metadata.jurisdiction = classification.jurisdiction;
    if (!result.metadata.filingType) result.metadata.filingType = classification.filingType;
    result.metadata.confidence = Math.min(result.metadata.confidence, classification.confidence);
    const diagnostic = assessMetadataCompleteness(result);
    return {
      result,
      diagnostic,
      manager: {
        stage: 0,
        totalStages: MANAGED_AGENT_ORDER.length + 1,
        agent: "metadata" as const,
        excerptChars: excerpt.length,
        attempts,
      },
      evaluation: {
        schemaValid: true as const,
        completeness: diagnostic.status,
      },
    };
  },

  async run(
    agent: AgentName,
    market: Market,
    filingText: string,
    context: { jurisdiction: Market; filingType: string; filingDate?: string | null; priorResults?: Record<string, unknown> },
  ): Promise<ManagedRun> {
    const schema: z.ZodTypeAny = AGENT_SCHEMAS[agent];
    const excerpt = buildAgentInput(agent, filingText);
    const input = agent === "synthesizer" ? synthesisInput(excerpt, context.priorResults) : excerpt;
    const managed = await withManagedRetry(
      () => runAgent(agent, market, input, schema, context),
    );
    const subtools: string[] = [];
    let result = managed.value;
    if (agent === "financials") {
      result = applyFinancialValidation(managed.value as FinancialsResult);
      subtools.push("financial-ratio-toolkit", "financial-statement-analyzer");
    }
    if (agent === "historian") {
      const history = managed.value as import("../contracts/analysis").HistoryResult;
      const validated = validateHistorianOutput(history, context.filingDate);
      if (!validated.timeline.length && !validated.events.length) {
        const fallback = extractDatedFilingEvents(excerpt);
        result = validateHistorianOutput({ ...history, events: fallback }, context.filingDate);
      } else result = validated;
      subtools.push("filing-timeline-extractor", "filing-timeline-extractor-validator");
    }
    if (agent === "market") {
      const marketResult = validateMarketOutput(managed.value as import("../contracts/analysis").MarketResult);
      const market = marketResult.market;
      if (market.competitors.length > 0) {
        market.externalResearchStatus = "not_needed";
      } else {
        try {
          const webPeers = await researchMarketPeers({
            jurisdiction: context.jurisdiction,
            industry: market.industry,
            filingExcerpt: excerpt,
          });
          const filingPeerNames = new Set(market.competitors.map(name => name.trim().toLowerCase()));
          const externalPeers = webPeers.filter(peer => !filingPeerNames.has(peer.name.trim().toLowerCase()));
          market.peerEvidence = [...(market.peerEvidence ?? []), ...externalPeers].slice(0, 12);
          market.competitors = [...market.competitors, ...externalPeers.map(peer => peer.name)].slice(0, 12);
          market.externalResearchStatus = externalPeers.length ? "complete" : "no_citable_results";
          if (externalPeers.length) subtools.push("cited-web-market-research");
        } catch (error) {
          console.warn("[agent:market] external peer search unavailable", error instanceof Error ? error.name : "unknown_error");
          market.externalResearchStatus = "unavailable";
        }
      }
      result = marketResult;
      subtools.push("filing-source-provenance-validator", "market-research-brief-period-comparison");
    }
    if (agent === "profiler") subtools.push("equity-research-tear-sheet-method");
    if (agent === "market") subtools.push("market-research-brief-analysis-framework");
    const diagnostic = assessCompleteness(agent, result, context);
    if (["profiler", "historian"].includes(agent)) {
      diagnostic.enrichmentStatus = "skipped";
      diagnostic.warnings = ["external_enrichment_unavailable"];
    }
    if (agent === "historian") {
      const history = result as import("../contracts/analysis").HistoryResult;
      if ((history.validationFlags?.length ?? 0) > 0) {
        diagnostic.warnings = [...(diagnostic.warnings ?? []), "historian_validation_flags"];
      }
    }
    if (agent === "market") {
      const market = result as import("../contracts/analysis").MarketResult;
      const researchStatus = market.market.externalResearchStatus;
      diagnostic.enrichmentStatus = researchStatus === "complete" ? "full" : researchStatus === "not_needed" ? "none" : "skipped";
      if (researchStatus === "no_citable_results") diagnostic.warnings = ["external_market_research_no_citations"];
      if (researchStatus === "unavailable") diagnostic.warnings = ["external_market_research_unavailable"];
      if ((market.market.validationFlags?.length ?? 0) > 0) {
        diagnostic.warnings = [...(diagnostic.warnings ?? []), "market_validation_flags"];
      }
    }
    const stage = MANAGED_AGENT_ORDER.indexOf(agent) + 1;
    return {
      result,
      diagnostic,
      manager: {
        stage,
        totalStages: MANAGED_AGENT_ORDER.length + 1,
        agent,
        excerptChars: excerpt.length,
        attempts: managed.attempts,
        subtools,
      },
      evaluation: {
        schemaValid: true,
        completeness: diagnostic.status,
      },
    };
  },
};

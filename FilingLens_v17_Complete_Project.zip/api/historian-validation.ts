import type { HistoryResult } from "../contracts/analysis";

type HistoryEvent = HistoryResult["events"][number];
type HistoryTimelineItem = HistoryResult["timeline"][number];
type Flag = NonNullable<HistoryResult["validationFlags"]>[number];

const EVENT_CATEGORIES = new Set([
  "incorporation_founding", "ipo_listing", "ma_acquisition", "capital_raise",
  "leadership_change", "regulatory_legal", "product_launch", "partnership_contract",
  "dividend_distribution", "restructuring", "accounting_restatement", "subsequent_event", "other",
]);

function categoryOf(value: string): string {
  const text = value.toLowerCase();
  if (EVENT_CATEGORIES.has(text)) return text;
  if (/ipo|listing|public offering|abertura de capital/.test(text)) return "ipo_listing";
  if (/acquisition|acquired|merger|acquisition|aquisi|fus[aã]o/.test(text)) return "ma_acquisition";
  if (/capital raise|offering|issuance|emiss[aã]o|aumento de capital/.test(text)) return "capital_raise";
  if (/leadership|director|ceo|board|administra|conselho|presidente/.test(text)) return "leadership_change";
  if (/regulat|legal|litigation|lawsuit|cvm|sec|processo|judicial|regulat[oó]ri/.test(text)) return "regulatory_legal";
  if (/product|launch|produto|lan[cç]amento/.test(text)) return "product_launch";
  if (/partner|contract|joint venture|parceria|contrato/.test(text)) return "partnership_contract";
  if (/dividend|distribution|juros sobre capital|dividendo/.test(text)) return "dividend_distribution";
  if (/restructur|reorganiza|recupera[cç][aã]o/.test(text)) return "restructuring";
  if (/restatement|reissu|reapresenta|retifica/.test(text)) return "accounting_restatement";
  if (/subsequent|subsequente|posterior/.test(text)) return "subsequent_event";
  if (/found|incorporat|funda[cç][aã]o|constitui[cç][aã]o/.test(text)) return "incorporation_founding";
  return "other";
}

function dateInfo(value: string): { granularity: "day" | "month" | "year"; time: number } | null {
  if (/^\d{4}$/.test(value)) return { granularity: "year", time: Date.UTC(Number(value), 0, 1) };
  if (/^\d{4}-\d{2}$/.test(value)) {
    const [year, month] = value.split("-").map(Number);
    if (month < 1 || month > 12) return null;
    return { granularity: "month", time: Date.UTC(year, month - 1, 1) };
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    const time = Date.parse(`${value}T00:00:00Z`);
    if (!Number.isFinite(time) || new Date(time).toISOString().slice(0, 10) !== value) return null;
    return { granularity: "day", time };
  }
  return null;
}

function filingDateTime(value?: string | null): number | null {
  if (!value) return null;
  const timestamp = Date.parse(value);
  return Number.isFinite(timestamp) ? timestamp : null;
}

function eventId(date: string, title: string): string {
  const slug = title.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase()
    .replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 64) || "event";
  return `evt-${date}-${slug}`;
}

function excerptSource(event: HistoryEvent) {
  const quote = event.sourceRef?.kind === "excerpt"
    ? event.sourceRef.quote
    : event.source?.quote;
  const section = event.sourceRef?.section ?? event.source?.section;
  if (!quote?.trim() || !section?.trim()) return null;
  return {
    section,
    page: event.sourceRef?.pageHint ?? event.source?.page ?? null,
    item: event.source?.item ?? null,
    sourceForm: event.sourceForm ?? event.source?.sourceForm ?? null,
    quote: quote.trim().slice(0, 600),
  };
}

/** Validates and normalizes historian output before the manager binds it. */
export function validateHistorianOutput(
  input: HistoryResult,
  filingDate?: string | null,
): HistoryResult {
  const flags: Flag[] = [];
  const filingTime = filingDateTime(filingDate);
  const limit = filingTime === null ? null : filingTime + 30 * 24 * 60 * 60 * 1000;
  const mark = (code: string, note: string, eventId?: string, reason?: string) => {
    flags.push({ code, note, ...(eventId ? { eventId } : {}), ...(reason ? { reason } : {}) });
  };
  if (filingTime === null) mark("FILING_DATE_UNAVAILABLE", "The filing date was unavailable, so the subsequent-events date window could not be checked.");

  const timeline = input.timeline.flatMap((item: HistoryTimelineItem) => {
    const info = dateInfo(item.year);
    if (!info) {
      mark("DROPPED", "Timeline item removed because its date is not an explicit YYYY, YYYY-MM, or YYYY-MM-DD value.", undefined, "invalid_date");
      return [];
    }
    if (item.sourceType === "external") {
      mark("DROPPED", "External timeline items cannot be verified by the connected sources in this analysis.", undefined, "external_source_unavailable");
      return [];
    }
    if (!item.source?.quote?.trim() || !item.source.section.trim()) {
      mark("DROPPED", "Timeline item removed because it has no exact filing quote and section reference.", undefined, "missing_excerpt");
      return [];
    }
    return [{ ...item, category: categoryOf(item.category), sourceType: "filing" as const }];
  });

  const seen: Array<{ id: string; title: string; time: number }> = [];
  const events = input.events.flatMap((event: HistoryEvent) => {
    const info = dateInfo(event.date);
    const title = event.title.trim().slice(0, 120);
    if (!info || !title) {
      mark("DROPPED", "Event removed because its date or title is missing or invalid.", undefined, "invalid_event");
      return [];
    }
    if (event.dateGranularity && event.dateGranularity !== info.granularity) {
      mark("DROPPED", "Event removed because its declared date granularity conflicts with the date value.", undefined, "date_granularity_mismatch");
      return [];
    }
    if (limit !== null && info.time > limit) {
      mark("DROPPED", "Event removed because its date is more than 30 days after the filing date.", undefined, "outside_subsequent_event_window");
      return [];
    }
    if (event.sourceType === "external" || event.sourceRef?.kind === "citation") {
      mark("DROPPED", "External event removed because this analysis has no connected research source to verify its citation.", undefined, "external_source_unavailable");
      return [];
    }
    const source = excerptSource(event);
    if (!source) {
      mark("DROPPED", "Event removed because it has no exact filing quote and section reference.", undefined, "missing_excerpt");
      return [];
    }
    const normalizedTitle = title.toLowerCase().replace(/[^a-z0-9\p{L}]+/gu, " ").trim();
    const duplicate = seen.find(item => item.title === normalizedTitle && Math.abs(item.time - info.time) <= 92 * 24 * 60 * 60 * 1000);
    if (duplicate) {
      mark("DROPPED", `Duplicate event removed; retained ${duplicate.id}.`, undefined, "duplicate_event");
      return [];
    }
    const id = eventId(event.date, title);
    seen.push({ id, title: normalizedTitle, time: info.time });
    return [{
      ...event,
      dateGranularity: info.granularity,
      title,
      category: categoryOf(event.category),
      materiality: event.materiality ?? "implied",
      sourceType: "filing" as const,
      confidence: event.confidence ?? "high",
      source,
      sourceRef: { kind: "excerpt" as const, section: source.section, pageHint: source.page ?? undefined, quote: source.quote },
      id,
    }];
  });

  return {
    ...input,
    timeline,
    events,
    enrichmentStatus: "skipped",
    validationFlags: [...(input.validationFlags ?? []), ...flags],
  };
}

import { useCallback, useEffect, useRef, useState } from "react";
import Dashboard from "@/components/Dashboard";
import type {
  AgentName,
  AnalysisDiagnostics,
  FilingClassification,
  FilingAnalysis,
  MetadataResult,
  ModuleDiagnostic,
} from "@contracts/analysis";

type Market = "us" | "br";
type Lang = "en" | "pt";
type Phase = "idle" | "working" | "confirm" | "done" | "error";

const T: Record<Lang, Record<string, string>> = {
  en: {
    badge: "FILING → DASHBOARD · SEC + CVM",
    h1a: "Drop a filing.",
    h1b: "Get an interactive dashboard.",
    lead: "Attach a 10-K, 10-Q, 8-K or S-1 (US), or a Formulário de Referência, DFP, ITR or Fato Relevante (Brazil). FilingLens detects the regulator path, applies filing-specific controls and renders the dashboard here.",
    s1t: "Pick your market",
    s1p: "Choose the tab for the filing's jurisdiction — US Companies (SEC) or Empresas Brasileiras (CVM/B3).",
    s2t: "Attach the filing",
    s2p: "Drag & drop or browse for the official filing PDF. That is the only input the engine needs.",
    s3t: "Get the dashboard",
    s3p: "Click Analyze. The embedded engine extracts the filing, applies its rules and generates the dashboard on the spot.",
    tabUs: "🇺🇸 US Companies",
    tabBr: "🇧🇷 Empresas Brasileiras",
    usDesc: "SEC path — for 10-K, 10-Q, 8-K and S-1 filings. FilingLens routes Items 1, 1A, 7 and 8 to the appropriate specialists and applies form-specific completeness rules.",
    brDesc: "CVM path — for Formulário de Referência, DFP, ITR and Fato Relevante. FilingLens uses Portuguese retrieval anchors, classifies risks and applies document-specific completeness rules.",
    drop1us: "Drop your 10-K or 10-Q here",
    drop1br: "Drop your FRE, DFP or ITR here",
    drop2: "or click to browse — PDF only",
    analyze: "▶ Analyze filing",
    extracting: "Reading the filing…",
    workingNote: "A metadata pre-stage and six specialized agents analyze the filing step by step. This takes a few minutes — please don't close this tab.",
    metadata: "Regulator metadata",
    confirmTitle: "Confirm the filing jurisdiction",
    confirmText: "The document contains mixed or low-confidence jurisdiction signals. Confirm the regulator path before analysis begins.",
    detected: "Detected",
    done: "Your dashboard is ready",
    download: "⬇ Download data (JSON)",
    again: "↺ Analyze another filing",
    hidden: "The analysis engine is embedded — rules run in the background and are never displayed.",
    tipUs: "💡 Best results: use the official PDF downloaded from SEC EDGAR. Upload one text-based PDF, up to 20 MB.",
    tipBr: "💡 Best results: use the official PDF from CVM's Empresas.NET. Upload one text-based PDF, up to 20 MB.",
    err_no_file: "No file received. Please attach the filing PDF.",
    err_unreadable_pdf: "This PDF could not be read (it may be scanned/image-only or corrupted). Try a text-based PDF.",
    err_too_little_text: "Very little text was extracted — this doesn't look like a complete filing.",
    err_ai_unavailable: "Analysis quota exhausted — this feature is temporarily unavailable. Please ask the site owner to top up.",
    err_content_rejected: "The document was rejected by the content filter.",
    err_ai_misconfigured: "The analysis engine is misconfigured. Ask the administrator to configure the AI provider.",
    err_ai_transient: "The analysis service is busy or timed out. Please try again in a moment.",
    err_internal: "Something went wrong on our side. Please try again.",
    footer: "FilingLens · Analysis runs on public regulatory filings (SEC EDGAR / CVM) · AI usage is billed to the site owner · Informational use only — not investment advice.",
  },
  pt: {
    badge: "DOCUMENTO → DASHBOARD · SEC + CVM",
    h1a: "Solte um documento.",
    h1b: "Receba um dashboard interativo.",
    lead: "Anexe um 10-K, 10-Q, 8-K ou S-1 (EUA), ou um Formulário de Referência, DFP, ITR ou Fato Relevante (Brasil). O FilingLens detecta a rota regulatória, aplica controles por tipo de documento e gera o dashboard aqui.",
    s1t: "Escolha seu mercado",
    s1p: "Selecione a aba da jurisdição do documento — US Companies (SEC) ou Empresas Brasileiras (CVM/B3).",
    s2t: "Anexe o documento",
    s2p: "Arraste e solte ou procure o PDF oficial do documento. É a única entrada que o motor precisa.",
    s3t: "Receba o dashboard",
    s3p: "Clique em Analisar. O motor embutido extrai o documento, aplica suas regras e gera o dashboard na hora.",
    tabUs: "🇺🇸 US Companies",
    tabBr: "🇧🇷 Empresas Brasileiras",
    usDesc: "Rota SEC — para 10-K, 10-Q, 8-K e S-1. O FilingLens encaminha os Itens 1, 1A, 7 e 8 aos especialistas corretos e aplica regras de completude específicas por formulário.",
    brDesc: "Rota CVM — para Formulário de Referência, DFP, ITR e Fato Relevante. O FilingLens usa âncoras em português, classifica riscos e aplica regras de completude por classe documental.",
    drop1us: "Arraste seu 10-K ou 10-Q aqui",
    drop1br: "Arraste seu FRE, DFP ou ITR aqui",
    drop2: "ou clique para procurar — somente PDF",
    analyze: "▶ Analisar documento",
    extracting: "Lendo o documento…",
    workingNote: "Um pré-estágio de metadados e seis agentes especializados analisam o documento passo a passo. Leva alguns minutos — não feche esta aba.",
    metadata: "Metadados regulatórios",
    confirmTitle: "Confirme a jurisdição do documento",
    confirmText: "O documento contém sinais mistos ou de baixa confiança. Confirme a rota regulatória antes do início da análise.",
    detected: "Detectado",
    done: "Seu dashboard está pronto",
    download: "⬇ Baixar dados (JSON)",
    again: "↺ Analisar outro documento",
    hidden: "O motor de análise é embutido — as regras rodam em segundo plano e nunca são exibidas.",
    tipUs: "💡 Melhores resultados: use o PDF oficial baixado do SEC EDGAR. Envie um PDF com texto de até 20 MB.",
    tipBr: "💡 Melhores resultados: use o PDF oficial do sistema Empresas.NET da CVM. Envie um PDF com texto de até 20 MB.",
    err_no_file: "Nenhum arquivo recebido. Anexe o PDF do documento.",
    err_unreadable_pdf: "Não foi possível ler este PDF (pode ser digitalizado como imagem ou estar corrompido). Tente um PDF com texto.",
    err_too_little_text: "Muito pouco texto foi extraído — isto não parece um documento completo.",
    err_ai_unavailable: "Cota de análise esgotada — este recurso está temporariamente indisponível. Peça ao dono do site para recarregar.",
    err_content_rejected: "O documento foi rejeitado pelo filtro de conteúdo.",
    err_ai_misconfigured: "O motor de análise está mal configurado. Peça ao administrador para configurar o provedor de IA.",
    err_ai_transient: "O serviço de análise está ocupado ou expirou. Tente novamente em instantes.",
    err_internal: "Algo deu errado do nosso lado. Tente novamente.",
    footer: "FilingLens · A análise usa documentos regulatórios públicos (SEC EDGAR / CVM) · O uso de IA é cobrado do dono do site · Uso apenas informativo — não constitui recomendação de investimento.",
  },
};

const AGENTS: { key: AgentName; en: string; pt: string }[] = [
  { key: "profiler", en: "Company profile", pt: "Perfil da companhia" },
  { key: "market", en: "Market & competitors", pt: "Mercado e concorrentes" },
  { key: "risks", en: "Risk factors", pt: "Fatores de risco" },
  { key: "financials", en: "Financial statements", pt: "Demonstrações financeiras" },
  { key: "historian", en: "Timeline & events", pt: "Linha do tempo e eventos" },
  { key: "synthesizer", en: "Executive summary", pt: "Resumo executivo" },
];

const STAGES = [
  { key: "metadata", en: "Regulator metadata", pt: "Metadados regulatórios" },
  ...AGENTS,
] as const;

export default function Home() {
  const [configured, setConfigured] = useState<boolean | null>(null);
  useEffect(() => { fetch("/api/status").then(r => r.json()).then(s => setConfigured(s.configured)).catch(() => setConfigured(false)); }, []);
  const [lang, setLang] = useState<Lang>("en");
  const [market, setMarket] = useState<Market>("us");
  const [file, setFile] = useState<File | null>(null);
  const [phase, setPhase] = useState<Phase>("idle");
  const [step, setStep] = useState(0);
  const [error, setError] = useState<string | null>(null);
  
  const [analysis, setAnalysis] = useState<FilingAnalysis | null>(null);
  const [failed, setFailed] = useState<string[]>([]);
  const [classification, setClassification] = useState<FilingClassification | null>(null);
  const [pendingText, setPendingText] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const t = useCallback((k: string) => T[lang][k] ?? k, [lang]);

  const pick = (f: File | undefined | null) => {
    if (!f || phase === "working") return;
    if (!f.name.toLowerCase().endsWith(".pdf") || f.size > 20 * 1024 * 1024) { setError(lang === "pt" ? "Selecione um PDF de até 20 MB." : "Select a PDF up to 20 MB."); setPhase("error"); return; }
    setFile(f);
    setError(null);
    setPhase("idle");
    setAnalysis(null);
    setClassification(null);
    setPendingText(null);
  };

  const runPipeline = async (text: string, confirmed: FilingClassification) => {
    setPhase("working");
    setStep(0);
    setMarket(confirmed.jurisdiction);
    setClassification({ ...confirmed, needsConfirmation: false });
    try {
      const planBody = await fetch("/api/analysis-plan")
        .then(response => (response.ok ? response.json() : null))
        .catch(() => null);
      const plannedCandidates: unknown[] = Array.isArray(planBody?.agents)
        ? (planBody.agents as unknown[])
        : [];
      const managedAgents: AgentName[] = plannedCandidates.filter(
        (agent): agent is AgentName => typeof agent === "string" && AGENTS.some(item => item.key === agent),
      );
      if (managedAgents.length === 0) managedAgents.push(...AGENTS.map(item => item.key));

      const diagnostics: AnalysisDiagnostics = {};
      const failedAgents: string[] = [];
      const metadataResponse = await fetch("/api/metadata", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, classification: confirmed }),
      });
      const metadataBody = await metadataResponse.json().catch(() => ({}));
      if (!metadataResponse.ok) {
        if (["ai_unavailable", "ai_misconfigured", "content_rejected"].includes(metadataBody.error)) {
          setError(t("err_" + metadataBody.error));
          setPhase("error");
          return;
        }
        throw new Error("metadata_request_failed");
      }
      const fallbackMetadata: MetadataResult["metadata"] = {
        jurisdiction: confirmed.jurisdiction,
        filingType: confirmed.filingType,
        reportingPeriod: null,
        filedAt: null,
        confidence: confirmed.confidence,
        cnpj: null,
        cvmDocumentClass: confirmed.jurisdiction === "br" ? confirmed.filingType : null,
        registryData: null,
        cik: null,
        sicCode: null,
        fiscalYearEnd: null,
        stateOfIncorporation: null,
        sources: [],
      };
      const metadata = (metadataBody.result as MetadataResult | undefined)?.metadata ?? fallbackMetadata;
      diagnostics.metadata = (metadataBody.diagnostic as ModuleDiagnostic | undefined) ?? {
        status: "incomplete",
        reason: "metadata_diagnostic_missing",
      };
      if (diagnostics.metadata.status === "failed") failedAgents.push("metadata");

      const parts: Record<string, unknown> = {};
      for (let i = 0; i < managedAgents.length; i++) {
        setStep(i + 1);
        const agent = managedAgents[i];
        try {
          const ares = await fetch("/api/agent", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              agent,
              market: confirmed.jurisdiction,
              filingType: metadata.filingType || confirmed.filingType,
              filingDate: metadata.filedAt,
              text,
              priorResults: agent === "synthesizer" ? parts : undefined,
            }),
          });
          const abody = await ares.json().catch(() => ({}));
          if (!ares.ok) {
            if (["ai_unavailable", "ai_misconfigured", "content_rejected"].includes(abody.error)) {
              setError(t("err_" + abody.error));
              setPhase("error");
              return;
            }
            throw new Error(abody.error || "agent_request_failed");
          }
          parts[agent] = abody.result;
          diagnostics[agent] = (abody.diagnostic as ModuleDiagnostic | undefined)?.status
            ? abody.diagnostic
            : { status: "incomplete", reason: "response_diagnostic_missing" };
        } catch {
          failedAgents.push(agent);
          diagnostics[agent] = { status: "failed", reason: "agent_request_failed" };
        }
      }

      const prof = parts.profiler as
        | { company: FilingAnalysis["company"]; kpis: FilingAnalysis["kpis"] }
        | undefined;
      const summaryPart = parts.synthesizer as
        | { summary: FilingAnalysis["summary"]; confidenceNotes?: FilingAnalysis["confidenceNotes"]; missingData?: string[] }
        | undefined;
      const companyFallback: FilingAnalysis["company"] = {
        name: file?.name.replace(/\.pdf$/i, "") ?? "Filing",
        ticker: null,
        exchange: null,
        filingType: metadata.filingType || confirmed.filingType,
        periodEnd: metadata.reportingPeriod ?? "",
        filedAt: metadata.filedAt,
        description: lang === "pt" ? "Perfil não disponível para este documento." : "Profile unavailable for this filing.",
      };
      const financialsFallback: FilingAnalysis["financials"] = {
        unit: confirmed.jurisdiction === "br" ? "R$ milhões" : "USD millions",
        years: [], revenue: [], netIncome: [], eps: null, grossMargin: null,
        operatingMargin: null, operatingCashFlow: null, capex: null, freeCashFlow: null,
        dividends: null, buybacks: null, totalAssets: null, totalLiabilities: null,
        totalEquity: null, totalDebt: null, cash: null, forwardGuidance: [], evidence: [],
      };
      const marketFallback: FilingAnalysis["market"] = {
        industry: "", competitors: [], geographies: [], segments: [],
      };
      const diagnosticMissing = Object.values(diagnostics).flatMap(item => item?.missing ?? []);
      const assembled: FilingAnalysis = {
        schemaVersion: "2.0",
        jurisdiction: confirmed.jurisdiction,
        metadata,
        company: prof?.company ?? companyFallback,
        kpis: prof?.kpis ?? [],
        market: (parts.market as { market: FilingAnalysis["market"] } | undefined)?.market ?? marketFallback,
        risks: (parts.risks as { risks: FilingAnalysis["risks"] } | undefined)?.risks ?? [],
        financials: (parts.financials as { financials: FilingAnalysis["financials"] } | undefined)?.financials ?? financialsFallback,
        timeline: (parts.historian as { timeline: FilingAnalysis["timeline"] } | undefined)?.timeline ?? [],
        events: (parts.historian as { events: FilingAnalysis["events"] } | undefined)?.events ?? [],
        historyValidationFlags: (parts.historian as { validationFlags?: FilingAnalysis["historyValidationFlags"] } | undefined)?.validationFlags ?? [],
        summary: summaryPart?.summary ?? [],
        confidenceNotes: summaryPart?.confidenceNotes ?? [],
        missingData: [...new Set([...(summaryPart?.missingData ?? []), ...diagnosticMissing])],
        diagnostics,
      };
      const dashboard = await fetch("/api/dashboard-data", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ analysis: assembled }),
      })
        .then(response => (response.ok ? response.json() : null))
        .catch(() => null);
      setAnalysis(dashboard?.dashboard ? { ...assembled, prebuiltDashboard: dashboard.dashboard } : assembled);
      setFailed(failedAgents);
      setPendingText(null);
      setPhase("done");
    } catch {
      setError(t("err_ai_transient"));
      setPhase("error");
    }
  };

  const analyze = async () => {
    if (!file || phase === "working") return;
    setPhase("working");
    setStep(-1);
    setError(null);
    setAnalysis(null);
    try {
      const form = new FormData();
      form.append("file", file);
      form.append("market", market);
      const res = await fetch("/api/extract", { method: "POST", body: form });
      const body = await res.json().catch(() => ({}));
      if (!res.ok || !body.text || !body.classification) {
        setError(t("err_" + (body.error || "internal")));
        setPhase("error");
        return;
      }
      const detected = body.classification as FilingClassification;
      setClassification(detected);
      if (detected.needsConfirmation) {
        setPendingText(body.text as string);
        setPhase("confirm");
        return;
      }
      await runPipeline(body.text as string, detected);
    } catch {
      setError(t("err_ai_transient"));
      setPhase("error");
    }
  };

  const confirmJurisdiction = async (jurisdiction: Market) => {
    if (!pendingText || !classification) return;
    const filingType = jurisdiction === classification.jurisdiction
      ? classification.filingType
      : jurisdiction === "br" ? "Documento CVM" : "SEC filing";
    await runPipeline(pendingText, {
      ...classification,
      jurisdiction,
      filingType,
      confidence: 1,
      needsConfirmation: false,
    });
  };

  const download = () => {
    if (!analysis) return;
    const blob = new Blob([JSON.stringify(analysis, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `filing-analysis-v2-${analysis.jurisdiction}-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  const reset = () => {
    setFile(null);
    setAnalysis(null);
    setFailed([]);
    setPhase("idle");
    setError(null);
    setClassification(null);
    setPendingText(null);
  };

  return (
    <div className="min-h-screen bg-[#0b0f1c] text-slate-100" style={{ backgroundImage: "radial-gradient(1200px 500px at 70% -10%, #16224a 0%, #0b0f1c 55%)" }}>
      <div className="mx-auto max-w-5xl px-6 pb-20 pt-8">
        {/* language switch */}
        <div className="mb-8 flex justify-end">
          <div className="flex rounded-full border border-slate-700 bg-slate-800/60 p-1">
            {(["en", "pt"] as Lang[]).map((l) => (
              <button
                key={l}
                onClick={() => setLang(l)}
                className={`rounded-full px-4 py-1.5 text-sm font-semibold transition ${lang === l ? "bg-gradient-to-r from-blue-600 to-cyan-500 text-white" : "text-slate-400 hover:text-white"}`}
              >
                {l === "en" ? "🇺🇸 English" : "🇧🇷 Português"}
              </button>
            ))}
          </div>
        </div>

        {configured === false && <div role="status" className="mb-6 rounded-xl border border-amber-500/50 bg-amber-500/10 p-4 text-sm text-amber-200">{lang === "pt" ? "A análise de documentos requer a configuração segura do provedor de IA pelo administrador. Nenhum documento será enviado até a configuração estar pronta." : "Document analysis requires the administrator to configure the AI provider securely. Documents will not be sent until configuration is ready."}</div>}
        {/* hero */}
        <span className="inline-block rounded-full border border-blue-500 bg-blue-500/10 px-4 py-1 text-xs tracking-wide text-blue-300">{t("badge")}</span>
        <h1 className="mt-5 text-4xl font-bold leading-tight">
          {t("h1a")} <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">{t("h1b")}</span>
        </h1>
        <p className="mt-3 max-w-3xl leading-relaxed text-slate-400">{t("lead")}</p>

        {phase !== "done" && (
          <>
            {/* tabs */}
            <div className="mt-10 flex border-b border-slate-700">
              {(["us", "br"] as Market[]).map((m) => (
                <button
                  key={m}
                  disabled={phase === "working"}
                  onClick={() => { setMarket(m); reset(); }}
                  className={`border-b-2 px-6 py-3 text-sm font-semibold transition ${market === m ? "border-cyan-400 text-white" : "border-transparent text-slate-400 hover:text-white"}`}
                >
                  {m === "us" ? t("tabUs") : t("tabBr")}
                </button>
              ))}
            </div>

            <p className="mt-5 max-w-3xl text-sm leading-relaxed text-slate-400">{market === "us" ? t("usDesc") : t("brDesc")}</p>

            {phase === "confirm" && classification && (
              <div className="mt-6 rounded-2xl border border-amber-400/50 bg-amber-400/10 p-6" role="alert">
                <h2 className="text-lg font-bold text-amber-100">{t("confirmTitle")}</h2>
                <p className="mt-2 text-sm leading-relaxed text-amber-100/80">{t("confirmText")}</p>
                <p className="mt-3 text-xs text-amber-200/80">
                  {t("detected")}: {classification.jurisdiction === "br" ? "CVM / Brazil" : "SEC / United States"} · {classification.filingType} · {Math.round(classification.confidence * 100)}%
                </p>
                <div className="mt-5 grid gap-3 sm:grid-cols-2">
                  <button onClick={() => confirmJurisdiction("br")} className="rounded-xl bg-emerald-600 px-4 py-3 text-sm font-bold text-white hover:bg-emerald-500">🇧🇷 CVM · Brasil</button>
                  <button onClick={() => confirmJurisdiction("us")} className="rounded-xl bg-blue-600 px-4 py-3 text-sm font-bold text-white hover:bg-blue-500">🇺🇸 SEC · United States</button>
                </div>
              </div>
            )}

            {phase !== "confirm" && <>
            {/* dropzone */}
            <div
              onClick={() => inputRef.current?.click()}
              onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => { e.preventDefault(); setDragOver(false); pick(e.dataTransfer.files?.[0]); }}
              className={`mt-5 cursor-pointer rounded-2xl border-2 border-dashed p-12 text-center transition ${dragOver ? "border-cyan-400 bg-slate-800/60" : "border-slate-700 bg-slate-900/60 hover:border-cyan-500/60"}`}
            >
              <div className="mb-3 text-4xl">📄</div>
              <div className="font-semibold">{file ? file.name : market === "us" ? t("drop1us") : t("drop1br")}</div>
              <div className="mt-1 text-xs text-slate-500">{file ? `${(file.size / 1024 / 1024).toFixed(1)} MB` : t("drop2")}</div>
              <span className="mt-4 inline-block rounded-full border border-slate-700 bg-slate-800 px-3 py-1 text-[11px] text-slate-400">
                {market === "us" ? "PDF · 10-K · 10-Q · SEC EDGAR" : "PDF · FRE · DFP · ITR · CVM Empresas.NET"}
              </span>
              <input ref={inputRef} type="file" accept=".pdf,application/pdf" className="hidden" onChange={(e) => pick(e.target.files?.[0])} />
            </div>

            {/* analyze */}
            <button
              onClick={analyze}
              disabled={!file || phase === "working" || configured !== true}
              className="mt-4 w-full rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 py-4 text-sm font-bold text-white transition enabled:hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
            >
              {phase === "working"
                ? step < 0
                  ? t("extracting")
                  : `${lang === "pt" ? "Etapa" : "Stage"} ${step + 1}/${STAGES.length} · ${lang === "pt" ? STAGES[step].pt : STAGES[step].en}`
                : t("analyze")}
            </button>

            {phase === "working" && (
              <div className="mt-4 rounded-xl border border-blue-500/40 bg-blue-500/10 p-4">
                <div className="flex items-center gap-3">
                  <div className="h-5 w-5 animate-spin rounded-full border-2 border-cyan-400 border-t-transparent" />
                  <span className="text-sm font-medium text-cyan-200">
                    {step < 0
                      ? t("extracting")
                      : `${lang === "pt" ? "Etapa" : "Stage"} ${step + 1}/${STAGES.length} · ${lang === "pt" ? STAGES[step].pt : STAGES[step].en}`}
                  </span>
                </div>
                <div className="mt-2 flex gap-1.5">
                  {STAGES.map((a, i) => (
                    <span key={a.key} className={`h-1.5 flex-1 rounded-full ${i < step ? "bg-emerald-400" : i === step ? "bg-cyan-400" : "bg-slate-700"}`} />
                  ))}
                </div>
                <p className="mt-2 text-xs text-slate-400">{t("workingNote")}</p>
              </div>
            )}

            {phase === "error" && error && (
              <div className="mt-4 rounded-xl border border-red-500/50 bg-red-500/10 p-4 text-sm text-red-200">{error}</div>
            )}
            </>}

            <div className="mt-4 rounded-xl border border-cyan-500/30 bg-cyan-500/5 p-4 text-xs leading-relaxed text-cyan-100/90">
              {market === "us" ? t("tipUs") : t("tipBr")}
            </div>
            <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">🔒 {t("hidden")}</div>
          </>
        )}

        {/* result */}
        {phase === "done" && analysis && (
          <div className="mt-10">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <h2 className="text-xl font-bold text-emerald-300">✓ {t("done")}</h2>
              <div className="flex gap-2">
                <button onClick={download} className="rounded-lg bg-gradient-to-r from-blue-600 to-blue-500 px-4 py-2 text-xs font-bold text-white hover:brightness-110">{t("download")}</button>
                <button onClick={reset} className="rounded-lg border border-slate-700 bg-slate-800 px-4 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-700">{t("again")}</button>
              </div>
            </div>
            {failed.length > 0 && (
              <div className="mb-4 rounded-xl border border-amber-500/50 bg-amber-500/10 p-4 text-sm text-amber-200">
                {lang === "pt" ? "Aviso: alguns módulos não puderam ser gerados" : "Note: some modules could not be generated"}
                {": "}
                {failed.map((f) => (lang === "pt" ? STAGES.find((a) => a.key === f)?.pt : STAGES.find((a) => a.key === f)?.en) ?? f).join(" · ")}
                {" — "}
                {lang === "pt"
                  ? "o dashboard abaixo mostra os módulos analisados com sucesso."
                  : "the dashboard below shows the modules that analyzed successfully."}
              </div>
            )}
            <Dashboard data={analysis} lang={lang} />
          </div>
        )}

        <footer className="mt-16 text-center text-xs leading-relaxed text-slate-500">{t("footer")}</footer>
      </div>
    </div>
  );
}

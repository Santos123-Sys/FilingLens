import app from '../api/boot';
type Env = { ASSETS: { fetch(request: Request): Promise<Response> }; KIMI_AGENTGW_BASE_URL?: string; KIMI_AGENTGW_API_KEY?: string };
export default {
  async fetch(request: Request, env: Env) {
    if (env.KIMI_AGENTGW_BASE_URL) process.env.KIMI_AGENTGW_BASE_URL = env.KIMI_AGENTGW_BASE_URL;
    if (env.KIMI_AGENTGW_API_KEY) process.env.KIMI_AGENTGW_API_KEY = env.KIMI_AGENTGW_API_KEY;
    if (new URL(request.url).pathname.startsWith('/api/')) return app.fetch(request);
    const asset = await env.ASSETS.fetch(request);
    if (asset.status === 404 && request.headers.get('accept')?.includes('text/html')) return env.ASSETS.fetch(new Request(new URL('/', request.url), request));
    return asset;
  }
};
